# Why a plugin?

**The plugin is cool! Why is it not shipped with Godot?**
I see a lot of people saying that the plugin should come with Godot, but I believe this should stay as a plugin since most of the people making games won't be using it. I'm flattered by your comments but this will remain a plugin :)